package com.mathmaniarobotics.customcocoa;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URI;

/**
 * This app is an order form for Custom Cocoa
 */
public class MainActivity extends AppCompatActivity {

    /**
     * Variables
     */
    int quantity = 0;
    int costPerCup = 5;
    String whippedCream = "";
    String sprinkles = "";
    String caramel = "";
    String nameString = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * This method is called when the Order button is clicked
     */
    public void submitOrder(View view) {
        costPerCup = 5;

        //ask for order name
        EditText editName = (EditText) findViewById(R.id.editName);
        nameString = editName.getText().toString();

        //does user want whipped cream?
        CheckBox whippedCreamCheckBox = (CheckBox) findViewById(R.id.chkWhippedCream);
        boolean hasWhippedCream = whippedCreamCheckBox.isChecked();

        //does user want sprinkles?
        CheckBox sprinklesCheckBox = (CheckBox) findViewById(R.id.chkSprinkles);
        boolean hasSprinkles = sprinklesCheckBox.isChecked();

        //does user want caramel?
        CheckBox caramelCheckBox = (CheckBox) findViewById(R.id.chkCaramel);
        boolean hasCaramel = caramelCheckBox.isChecked();

        Log.i("MainActivity","The price is $" + quantity*costPerCup + " and the whipped cream is " + hasWhippedCream);

        //calculate price
        int price = calculatePrice(hasWhippedCream, hasSprinkles, hasCaramel);
        String priceMessage = createOrderSummary(price, hasWhippedCream, hasSprinkles, hasCaramel);

        //display order summary on screen - or comment out if ready to email order
        //displayMessage(priceMessage);

        //display order summary in an email to send to cocoa shop
        composeEmail(getString(R.string.email_subject)+" "+nameString, priceMessage);
        }



public void composeEmail(String subject, String order) {
    Intent intent = new Intent(Intent.ACTION_SENDTO);
    intent.setType("*/*");
    intent.setData(Uri.parse("mailto:"));
    intent.putExtra(Intent.EXTRA_SUBJECT, subject);
    intent.putExtra(Intent.EXTRA_TEXT, order);
    if (intent.resolveActivity(getPackageManager()) != null) {
        startActivity(intent);
    }
}

    /**
     * This method is called when the plus button is clicked
     */
    public void increment(View view) {
        if (quantity < 100) {
            quantity++;
            displayQuantity(quantity);
        } else {
            Context context = getApplicationContext();
            CharSequence text = getString(R.string.max_order);
            int duration = Toast.LENGTH_SHORT;

            Toast toast;
            Toast.makeText(context, text, duration).show();
        }

    }

    /**
     * This method is called when the minus button is clicked
     */
    public void decrement(View view) {
        if (quantity > 0) {
            quantity--;
            displayQuantity(quantity);
        } else {
            Context context = getApplicationContext();
            CharSequence text = getString(R.string.min_order);
            int duration = Toast.LENGTH_SHORT;

            Toast toast;
            Toast.makeText(context, text, duration).show();
        }

    }

    /**
     * This method displays the given quantity of cups on the screen
     *
     * @param number of cups
     */
    private void displayQuantity(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.txtTotal);
        quantityTextView.setText("" + number);
    }

    /**
     * This method calculates the total price
     *
     * @param hasWhippedCream if ordered whipped cream
     * @param hasSprinkles if ordered sprinkles
     * @param hasCaramel if ordered caramel
     *
     * @return price which is quantity * costPerCup
     */
    public int calculatePrice(boolean hasWhippedCream, boolean hasSprinkles, boolean hasCaramel) {
        if (hasWhippedCream) {
            costPerCup +=1;
            whippedCream = getString((R.string.yes));
        }
        if (hasSprinkles) {
            costPerCup +=1;
            sprinkles = getString(R.string.yes);
        }
        if (hasCaramel) {
            costPerCup +=2;
            caramel = getString(R.string.yes);
        }
        return quantity * costPerCup;
        }

    /**
     * This method creates an order summary
     *
     * @param price is the total price
     * @param hasWhippedCream tells us whether or not to add whipped cream
     * @param hasSprinkles tells us whether or not to add whipped cream
     * @param hasCaramel tells us whether or not to add whipped cream
     * @return message of the order summary
     */
    private String createOrderSummary(int price, boolean hasWhippedCream, boolean hasSprinkles, boolean hasCaramel) {
        String priceMessage = getString(R.string.order_summary);
        priceMessage += "\n "+getString(R.string.order_quantity) + ": "+quantity;
        priceMessage += "\n "+getString(R.string.add_whipped_cream) + " ($1) "+whippedCream;
        priceMessage += "\n "+getString(R.string.add_sprinkles) + " ($1) "+sprinkles;
        priceMessage += "\n "+getString(R.string.add_caramel) + " ($2) "+caramel;
        priceMessage += "\n\n "+getString(R.string.total)+": $" + price;
        //priceMessage += "\nThanks for your order";
        return priceMessage;
    }

    /**
     * This method displays the Order Summary
     */
    private void displayMessage(String message) {
        TextView priceOrderSummaryView = (TextView) findViewById(R.id.txtOrderSummary);
        priceOrderSummaryView.setText(message);
    }

}